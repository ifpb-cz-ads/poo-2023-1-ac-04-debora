
package com.mycompany.questao01;
public class Conta {

private String nome;
private Integer numero;
private double saldo;
//construtor
    public Conta(String nome, Integer numero, double saldo){
        super();
        this.nome = nome;
        this.numero = numero;
        this.saldo = 0;
    }

//metodos especiais
    public void setNome(String nome) {
        this.nome = nome;
    }


    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    //metodos normmais
    public boolean depositar (double valor){
        if(valor >0){
            saldo = saldo + valor;
            return true;
        }
    return false;
        
    }
    
    public boolean sacar(double valor){
       if(saldo - valor >= 0 && valor>=0){ 
        saldo = saldo- valor; 
        return true;
       }
       return false;
    }
   
}
