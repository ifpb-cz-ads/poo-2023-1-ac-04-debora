//Escreva um modelo para representar uma lâmpada que está à venda em
//um supermercado. Que dados devem ser representados por esse modelo?
package com.mycompany.supermercado;

public class Lampada {
   public String modelo;
   public String marca;
   public double preco;
   public String voltagem;
 //construtor  
//public Lampada(String modelo, String marca, float preco){
  // this.modelo = modelo;
  // this.marca = marca;
  // this.preco = 0;
//}

//metodos especiais
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getVoltagem() {
        return voltagem;
    }

    public void setVoltagem(String voltagem) {
        this.voltagem = voltagem;
    }
    
//metodos normais
    public void verProduto(){
        System.out.println("---l-a-m-p-a-d-a-s---");
        System.out.println("O modelo da lampada eh:" +this.getModelo());
        System.out.println("A marca eh:" +this.getMarca());
        System.out.println("O preço atual dela eh:" +this.getPreco());
        System.out.println("A voltagem da lampada eh:" +this.getVoltagem());
        System.out.println("--------f-i-m--------");
        
    }
}
