package com.mycompany.supermercado;

public class Supermercado {

    public static void main(String[] args) {
        
        Lampada lampada1 = new Lampada();
        
            lampada1.setModelo("fluroscente");
            lampada1.setMarca("BIC");
            lampada1.setPreco(29.00);
            lampada1.setVoltagem("40w");
            lampada1.verProduto();
    }
}
