package com.mycompany.atividade1;

public class Atividade1 {
    
private int numero;
    public static void main(String[] args) {
     
        ContaBanco p1 = new ContaBanco();
        
        p1.setNumconta(1111);
        p1.abrirConta("CC");
        p1.setDono("JUBILEU");
        p1.sacar(10);
        
        ContaBanco p2 = new ContaBanco();
        p2.setNumconta(2222);
        p2.setTipo("CP");
        p2.setDono("CREUZAA");
        p2.abrirConta("CP");
        p2.depositar(500);
        
        p1.estadoatual();
        p2.estadoatual();
        
    }
}
