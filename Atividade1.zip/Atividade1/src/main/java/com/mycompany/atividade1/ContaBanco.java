package com.mycompany.atividade1;

public class ContaBanco {
    //ATRIBUTOS
    public int numconta;
    protected String tipo;
    private String dono;
    private float saldo;
    private boolean status;
    
    public void estadoatual(){
        System.out.println("numConta:" + this.numconta);
        System.out.println("tipo: " + this.tipo);
        System.out.println("Dono: " + this.dono);
        System.out.println("Saldo: " + this.saldo);
        System.out.println("Status: " + this.status);
        System.out.println("------------------------");
    }
    
    //CONSTRUTOR
    public ContaBanco() {
        
    }
    
 //METODOS ESPECIAIS
    public int getNumconta() {
        return numconta;
    }

    public void setNumconta(int numconta) {
        this.numconta = numconta;
    }

    public String getTipo() {
        return tipo;
    }

 
    public void setTipo(String tipo) {    
        this.tipo = tipo;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    
    //METODOS NORMAIS
    public void abrirConta(String t){
        this.setTipo(t);
        this.setStatus(true);
        if ( t == "CC") {
            this.setSaldo(50);
        } else if (t == "CP") {
            this.setSaldo(150);
        }
    }
    public void fecharConta(){
        if (this.getSaldo()> 0){
            System.out.println("Erro! Sua conta ainda possui saldo.");
        }
        else if (this.getSaldo()< 0){
        System.out.println("Erro! Sua conta possui débito.");
    }
        else{
            this.setStatus(false);
            System.out.println("Sua conta foi fechada com sucesso!");
        }
    }
    public void depositar(float v){
        if (this.status = true){
            this.setSaldo(this.getSaldo()+ v);
            System.out.println("Depósito efetuado com sucesso na conta de:" + this.getDono());
        }
        else {
            System.out.println("Impossivel efetuar depósito com a conta fechada");
        }
    }
    public void sacar(float v){
        if (this.status = true){
            if (getSaldo()>= v){
            this.setSaldo(this.getSaldo() - v);
            System.out.println("Saque efetuado com sucesso na conta de:" + this.getDono());
        } else {
            System.out.println("Saldo insuficiente para saque informado");
            } 
        }  else { 
            System.out.println("Impossivel sacar de conta fechada!");
                }
        }
    public void pagarMensalidade(){
        int v = 0;
        if (this.getTipo() == "CC") {
            v = 12;
        } else if (this.getTipo() == "CP") {
            v=20;
        }
        if (this.status == true){
            this.setSaldo(this.getSaldo() - v);
            System.out.println("Mensalidade paga por:" + this.getDono());   
        }
        else{
            System.out.println("Impossivel pagar mensalidade de conta fechada!");
        }
    }
}
